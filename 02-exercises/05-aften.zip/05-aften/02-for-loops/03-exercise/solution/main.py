"""
Solution to exercise 3

Create a loop using the range function that prints the odd numbers from 1 to 10
"""
for i in range(1, 10, 2):
  print(i)