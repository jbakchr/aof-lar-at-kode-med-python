"""
Exercise 7

Just loop through a range of numbers from 1 to 5 and print something in an else
block when the loop finishes
"""

for i in range(1, 6):
  print(i)
else:
  print("I'm done!")