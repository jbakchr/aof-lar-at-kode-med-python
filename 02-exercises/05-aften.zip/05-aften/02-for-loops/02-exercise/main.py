"""
Exercise 2

Create a simple range loop that'll print all numbers from 1 to 10
"""

for i in range(1, 11):
  print(i)