"""
Exercise 4

Given the below list loop through the list printing each element
"""
groceries = ["apples", "bananas", "beer", "cheese", "salad"]

for el in groceries:
  print(el)