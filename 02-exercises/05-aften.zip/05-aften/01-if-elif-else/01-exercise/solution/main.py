"""
EXERCISE

For now just play around with all control structures, i.e.:
- if
- elif
- else
"""

if 10 == 10:
  print("wauw ..")


if "Jonas" == "God":
  print("No he's not")
else:
  print("I'm the true god!")


if "You getting it?" == "Yes!":
  print("Good ..")
elif 10 > 20:
  print("Hmmm .. are you sure!?")
else:
  print("Might it have been a Danish woman named 'Else' who's the creator of the else block?")