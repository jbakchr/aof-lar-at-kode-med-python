"""
EXERCISE

For now just play around with all control structures, i.e.:
- if
- elif
- else
"""
