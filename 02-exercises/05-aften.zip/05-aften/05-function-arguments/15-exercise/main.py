"""
Exercise 15

Given the below two list of teams, create a function that takes in an arbitary numbers
of arguments and print each team
"""

# Define function below this line


team1 = ["Jonas", "Mogens"]
team2 = ["Palle", "Jørgen"]

# Call your function below this line