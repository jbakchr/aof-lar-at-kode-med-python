"""
Exercise 16

Create a function with the below arguments in the mentioned order and call the function
using keyword arguments in reverse order:
- age
- name
"""
