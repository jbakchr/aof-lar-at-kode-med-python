"""
Exercise 17

Create a function with an arbitary number of keyword arguments and print
each one
"""
