"""
Exercise 14

Create a function that takes a number as a argument, raises that number to the
power of 2 and prints it.
"""
def exponent(num, exp):
  print(num ** exp)

exponent(5)