"""
Exercise 14

Create a function that takes a number as a paratemer, raises that number to the
power of 2 and returns it
"""
def exponent(num):
  return num ** 2