"""
Exercise 13

Given the function below your job is to simply call the function
"""
def awesome_function():
  print("Learning to code is SO awesome!")

awesome_function()