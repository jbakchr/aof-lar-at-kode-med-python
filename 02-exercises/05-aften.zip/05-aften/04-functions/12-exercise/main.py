"""
Exercise 12

Create a simple function that doesn't take any parameters and that prints something
"""
def hey():
  print("hey")

hey()