"""
Exercise 9

Create a while loop that'll print the numbers from 1 to 10
"""
num = 1
while num <= 10:
  print(num)
  num += 1