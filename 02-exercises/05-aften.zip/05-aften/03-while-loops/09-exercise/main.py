"""
Exercise 9

Create a while loop that'll print the numbers from 1 to 10
"""

i = 1
while i <= 10:
  print(i)
  i += 1